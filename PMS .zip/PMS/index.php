<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
<div align="center">
<h1>Welcome to Property Management System</h1>
<br>
<br>
<a href="LoginPage/">
<button style="width:200px;height:25px; background-color:white;">LOGIN</button>
</a>
<br>
<br>
<a href="RegistrationPages/">
<button style="width:200px;height:25px;background-color:limegreen;">REGISTER</button>
</a>


</div>
    
</body>
</html>