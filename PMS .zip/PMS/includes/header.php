<div align="center" style = "width:100%;height:50px;background-color:black;">

<a href="../index.php"><button style="width:20%;height:100%; background-color:blue; ">Home</button> </a>

</div>