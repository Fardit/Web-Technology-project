<?php
header("location:Registration.php");
?>